package main;

public class BangunDatar {
    private String jenis;
    
    public String getJenis(){
        return jenis;
    }
    public void setJenis(String jenis){
        this.jenis = jenis;
    }
    public double luas(){
        System.out.println("hitung luas");
        return 0;
    }
    public double keliling(){
        System.out.println("hitung keliling");
        return 0;
    }
}
