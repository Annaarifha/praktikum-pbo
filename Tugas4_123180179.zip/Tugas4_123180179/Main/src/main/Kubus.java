package main;

public class Kubus extends Persegi{
    public double volume(double sisi){
        return sisi*sisi*sisi;
    }
}
